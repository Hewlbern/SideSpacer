
var x = document.getElementById("HomeNav");
var y = document.getElementById("SpacesNav");
var z = document.getElementById("PricingNav");
var a = document.getElementById("HowitworksNav");
var b = document.getElementById("ContactNav");
var c = document.getElementById("LogOutNav");
var d = document.getElementById("SignUpNav");
var e = document.getElementById("LogInNav");
function Swap1() {
    if (x.classList.contains ('active')) {
        console.log('yep!');
        y.classList.remove('active');
        z.classList.remove('active');
        a.classList.remove('active');
        b.classList.remove('active');
        c.classList.remove('active');
        d.classList.remove('active');
        e.classList.remove('active');

    } else {
        x.classList.contains ('active');
        y.classList.remove('active');
        z.classList.remove('active');
        a.classList.remove('active');
        b.classList.remove('active');
        c.classList.remove('active');
        d.classList.remove('active');
        e.classList.remove('active');
    }
}

function Swap2() {
if (y.classList.contains ('active')) {
    x.classList.remove('active');
    z.classList.remove('active');
    a.classList.remove('active');
    b.classList.remove('active');
    c.classList.remove('active');
    d.classList.remove('active');
    e.classList.remove('active');

} else {
    y.classList.add ('active');
    x.classList.remove('active');
    z.classList.remove('active');
    a.classList.remove('active');
    b.classList.remove('active');
    c.classList.remove('active');
    d.classList.remove('active');
    e.classList.remove('active');
}}

function Swap3() {
if (z.classList.contains ('active')) {
    x.classList.remove('active');
    y.classList.remove('active');
    a.classList.remove('active');
    b.classList.remove('active');
    c.classList.remove('active');
    d.classList.remove('active');
    e.classList.remove('active');

} else {
    z.classList.add ('active')
    y.classList.remove('active');
    x.classList.remove('active');
    a.classList.remove('active');
    b.classList.remove('active');
    c.classList.remove('active');
    d.classList.remove('active');
    e.classList.remove('active');
}}


function Swap4() {
if (a.classList.contains ('active')) {
    x.classList.remove('active');
    y.classList.remove('active');
    z.classList.remove('active');
    b.classList.remove('active');
    c.classList.remove('active');
    d.classList.remove('active');
    e.classList.remove('active');

} else {
    a.classList.add ('active');
    y.classList.remove('active');
    z.classList.remove('active');
    x.classList.remove('active');
    b.classList.remove('active');
    c.classList.remove('active');
    d.classList.remove('active');
    e.classList.remove('active');
}}

function Swap5() {
if (b.classList.contains ('active')) {
    x.classList.remove('active');
    y.classList.remove('active');
    z.classList.remove('active');
    a.classList.remove('active');
    c.classList.remove('active');
    d.classList.remove('active');
    e.classList.remove('active');

} else {
    b.classList.add ('active');
    y.classList.remove('active');
    z.classList.remove('active');
    a.classList.remove('active');
    x.classList.remove('active');
    c.classList.remove('active');
    d.classList.remove('active');
    e.classList.remove('active');
}}

function Swap6() {
if (c.classList.contains ('active')) {
    x.classList.remove('active');
    y.classList.remove('active');
    z.classList.remove('active');
    b.classList.remove('active');
    a.classList.remove('active');
    d.classList.remove('active');
    e.classList.remove('active');

} else {
    c.classList.add ('active');
    y.classList.remove('active');
    z.classList.remove('active');
    a.classList.remove('active');
    b.classList.remove('active');
    x.classList.remove('active');
    d.classList.remove('active');
    e.classList.remove('active');
}}

function Swap7() {
if (d.classList.contains ('active')) {
    x.classList.remove('active');
    z.classList.remove('active');
    a.classList.remove('active');
    b.classList.remove('active');
    c.classList.remove('active');
    y.classList.remove('active');
    e.classList.remove('active');

} else {
    d.classList.add ('active');
    y.classList.remove('active');
    z.classList.remove('active');
    a.classList.remove('active');
    b.classList.remove('active');
    c.classList.remove('active');
    x.classList.remove('active');
    e.classList.remove('active');
}}

function Swap8() {
if (e.classList.contains ('active')) {
    x.classList.remove('active');
    z.classList.remove('active');
    a.classList.remove('active');
    b.classList.remove('active');
    c.classList.remove('active');
    d.classList.remove('active');
    y.classList.remove('active');

} else {
    e.classList.add ('active');
    y.classList.remove('active');
    z.classList.remove('active');
    a.classList.remove('active');
    b.classList.remove('active');
    c.classList.remove('active');
    d.classList.remove('active');
    x.classList.remove('active');
}}







